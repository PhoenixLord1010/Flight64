# Flight64
3D Game Project

Get the guy to the end using the warp pads. Hold jump to glide, hold attack for a longer reaching strike.

Controls
-W/S: move forward/backward
-A/D: turn left/right
-NUM 5: spear attack
-NUM ENTER: dash attack
-NUM 0: jump / double jump / glide

-NUM 2/4/6/8: move camera
-NUM +/-: zoom in/out